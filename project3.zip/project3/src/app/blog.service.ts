import {Injectable, EventEmitter} from '@angular/core';


@Injectable()
export class BlogService {
  private posts: Post[];
  private newId: number;
  change: EventEmitter<Post> = new EventEmitter();

  constructor() {
    this.fetchPosts();
  }

  private fetchPosts(): void {
    this.posts = JSON.parse(localStorage.getItem('posts')) || [];
    this.newId = JSON.parse(localStorage.getItem('newId')) || 1;
  }

  getPosts(): Post[] {
    return this.posts;
  }

  getPost(id: number): Post {
    let p = this.posts.find(h => h.postid === id);
    this.change.emit(p);
    return p;
  }


  newPost(): Post {
    let p = new Post(this.newId++);
    this.posts.push(p);
    localStorage.setItem('posts', JSON.stringify(this.posts));
    localStorage.setItem('newId', JSON.stringify(this.newId));
    return p;
  }

  update(post: Post): void {
    if (post) {
      let old = this.getPost(post.postid);
      if (old) {
        // console.log('modified');
        old.title = post.title;
        old.body = post.body;
        old.modified = new Date();
        localStorage.setItem('posts', JSON.stringify(this.posts));
      }
    }
  }

  delete(id: number): void {
    let old = this.getPost(id);

    if (old) {
      this.posts.splice(this.posts.indexOf(old), 1);
      localStorage.setItem('posts', JSON.stringify(this.posts));
    }
  }
}

export class Post {

  public created: Date;

  constructor(public postid: number,
              public title = '',
              public body = '',
              public modified = new Date()) {
    this.created = new Date();
  }
}
